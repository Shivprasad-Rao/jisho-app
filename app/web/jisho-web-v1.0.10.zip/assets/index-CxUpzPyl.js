const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Cndw2viS.js","assets/nativeUpdate-DtuZPPTN.js","assets/index-eeEBY2sL.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-eeEBY2sL.js";import{q as o}from"./nativeUpdate-DtuZPPTN.js";const i=o("Share",{web:()=>r(()=>import("./web-Cndw2viS.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{i as Share};
