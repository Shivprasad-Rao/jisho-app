const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-Dnn9cYw8.js","assets/nativeUpdate-BB7z6VIQ.js","assets/index-eeEBY2sL.js"])))=>i.map(i=>d[i]);
import{_ as r}from"./index-eeEBY2sL.js";import{q as o}from"./nativeUpdate-BB7z6VIQ.js";const i=o("Share",{web:()=>r(()=>import("./web-Dnn9cYw8.js"),__vite__mapDeps([0,1,2])).then(e=>new e.ShareWeb)});export{i as Share};
