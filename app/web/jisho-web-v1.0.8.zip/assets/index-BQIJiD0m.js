const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/web-XM2x6EIw.js","assets/nativeUpdate-BB7z6VIQ.js","assets/index-eeEBY2sL.js"])))=>i.map(i=>d[i]);
import{_ as e}from"./index-eeEBY2sL.js";import{q as o}from"./nativeUpdate-BB7z6VIQ.js";const i=o("Browser",{web:()=>e(()=>import("./web-XM2x6EIw.js"),__vite__mapDeps([0,1,2])).then(r=>new r.BrowserWeb)});export{i as Browser};
